<?php
include 'includes/library.php'; 
$pdo = connectDB();
?>

<!--------------------------------- HTML PAGE---------------------------------------->
<!DOCTYPE html>
<html lang="en">
<head>
    <?php
    $page_title = "Thank You"; 
    include "includes/metadata.php";
    ?>
    <link rel="stylesheet" href="styles/getting_started.css" />
</head>
<body>

</body>
</html>